"""Constants for the HA-RAG Expose API component."""

DOMAIN = "ha_rag_expose_api"
